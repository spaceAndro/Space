
document.addEventListener("DOMContentLoaded", function() {
        // 로그아웃 버튼 클릭 시 AJAX 요청
        const logoutBtn = document.getElementById("logoutBtn");

        if (logoutBtn) {
            logoutBtn.addEventListener("click", function(event) {
                event.preventDefault(); // 기본 링크 동작 막기

                const csrfToken = document.querySelector('meta[name="_csrf"]').getAttribute('content');
                const csrfHeader = document.querySelector('meta[name="_csrf_header"]').getAttribute('content');

                fetch("/logout", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                        [csrfHeader]: csrfToken // CSRF 토큰 추가
                    }
                })
                .then(response => {
                    if (response.ok) {
                        window.location.href = "/index"; // 로그아웃 후 리다이렉트할 페이지로 이동
                    } else {
                        console.error("로그아웃 요청 실패: " + response.status);
                    }
                })
                .catch(error => {
                    console.error("로그아웃 중 오류 발생: ", error);
                });
            });
        }

		// 페이지 요청 시 401 에러 처리
		fetch(window.location.href)
		    .then(response => {
		        console.log("페이지 요청 상태 코드:", response.status); // 상태 코드 출력

		        if (response.status === 401) { // 401 에러 발생 시
		            showLoginModal(); // 로그인 모달 띄우기
		        } else if (!response.ok) {
		            return response.text().then(text => {
		                console.error("응답 본문:", text); // 응답 본문 출력
		            });
		        }
		    })
		    .catch(error => console.error("페이지 접근 오류: ", error));

			   // 로그인 버튼 클릭 시 모달 열기
			           const loginBtn = document.getElementById("loginBtn");
			           if (loginBtn) {
			               loginBtn.addEventListener("click", function(event) {
			                   event.preventDefault(); // 기본 동작 막기

			                   const xhr = new XMLHttpRequest();
			                   xhr.open("GET", "/login", true);
			                   xhr.onreadystatechange = function() {
			                       if (xhr.readyState === 4) {
									console.log("AJAX 요청 상태 코드:", xhr.status); // 상태 코드 출력
			                           if (xhr.status === 200) {
			                               document.getElementById("modalContent").innerHTML = xhr.responseText;
			                               document.getElementById("loginModal").style.display = "flex";
			                               document.body.style.overflow = "auto";
			                           } else if (xhr.status === 401) {
			                               showLoginModal(); // 로그인 모달 띄우기
			                           } else {
			                               console.error("AJAX 요청 실패: " + xhr.status);
			                           }
			                       }
			                   };
			                   xhr.send();
			               });
			           }

        // 회원가입 버튼 클릭 시 모달 열기
        const signupBtn = document.getElementById("signupBtn");
        if (signupBtn) {
            signupBtn.addEventListener("click", function(event) {
                event.preventDefault(); // 기본 동작 막기

                const xhr = new XMLHttpRequest();
				
                xhr.open("GET", "/signup", true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        document.getElementById("signupModalContent").innerHTML = xhr.responseText;
                        document.getElementById("signupModal").style.display = "flex";
						
						
						// 여기서 옵션 추가 코드 실행
						                const ageSelect = document.getElementById("age");
						                for (let i = 10; i <= 80; i++) {
						                    const option = document.createElement("option");
						                    option.value = i;
						                    option.text = i;
						                    ageSelect.appendChild(option);
						                }
						
						
                        document.body.style.overflow = "auto";
						
                    } else if (xhr.readyState === 4) {
                        console.error("AJAX 요청 실패: " + xhr.status);
                    }
                };
                xhr.send();
            });
        }
    });
	// 모달 닫기 버튼 클릭 시 모달 닫기
	const closeModal = document.getElementById("closeModal");
	if (closeModal) {
	    closeModal.addEventListener("click", function() {
	        document.getElementById("loginModal").style.display = "none";
	        document.body.style.overflow = "auto"; // 스크롤 다시 가능하게
	    });
	}

	// 회원가입 모달 닫기 버튼 클릭 시 모달 닫기
	const closeSignupModal = document.getElementById("closeSignupModal");
	if (closeSignupModal) {
	    closeSignupModal.addEventListener("click", function() {
	        document.getElementById("signupModal").style.display = "none";
	        document.body.style.overflow = "auto"; // 스크롤 다시 가능하게
	    });
	}

    // 드롭다운 토글 함수
    function toggleDropdown(event) {
        event.stopPropagation();  // 클릭 이벤트가 상위로 전달되지 않도록
        const dropdown = document.getElementById("userDropdown");
        dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    // 페이지의 다른 곳을 클릭했을 때 드롭다운을 닫는 기능
    window.onclick = function(event) {
        if (!event.target.matches('.user-icon')) {
            const dropdown = document.getElementById("userDropdown");
            if (dropdown.style.display === "block") {
                dropdown.style.display = "none";
            }
        }
    }
	// 로그인 모달을 띄우는 함수
	function showLoginModal() {
	    document.getElementById("loginModal").style.display = "flex";
	    document.body.style.overflow = "hidden"; // 스크롤 막기
	}
