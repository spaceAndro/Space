document.addEventListener("DOMContentLoaded", function () {
  const calendarBody = document.querySelector("#calendar tbody");
  const selectedDateInfo = document.getElementById("selectedDate");
  const selectedBreakfast = document.getElementById("selectedBreakfast");
  const selectedLunch = document.getElementById("selectedLunch");
  const selectedDinner = document.getElementById("selectedDinner");
  const yearDisplay = document.getElementById("yearDisplay");
  const monthDisplay = document.getElementById("monthDisplay");

  const today = new Date();
  let currentMonth = today.getMonth();
  let currentYear = today.getFullYear();
  let todayDate = today.getDate();

  const holidays = {
    "01-01": "신정",
    "03-01": "삼일절",
    "05-05": "어린이날",
    "06-06": "현충일",
    "08-15": "광복절",
    "10-01": "국군의 날",
    "10-03": "개천절",
    "10-09": "한글날",
    "12-25": "성탄절",
  };

  const lunarHolidays = {
    설날: ["2024-02-10", "2025-01-29"],
    추석: ["2024-09-17", "2025-10-06"],
    부처님오신날: ["2024-05-15", "2025-05-04"]
  };

  function updateYearMonthDisplay() {
    const monthNames = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'];
    yearDisplay.textContent = `${currentYear}년`;
    monthDisplay.textContent = `${monthNames[currentMonth]}`;
  }

  function displayTodayInfo() {
    selectedDateInfo.textContent = `${today.getFullYear()}년 ${today.getMonth() + 1}월 ${todayDate}일`;
    selectedBreakfast.textContent = "아침: 오늘의 아침 메뉴";
    selectedLunch.textContent = "점심: 오늘의 점심 메뉴";
    selectedDinner.textContent = "저녁: 오늘의 저녁 메뉴";
  }

  function isLunarHoliday(year, month, day) {
    const dateString = `${year}-${("0" + (month + 1)).slice(-2)}-${("0" + day).slice(-2)}`;
    for (let holiday in lunarHolidays) {
      if (lunarHolidays[holiday].includes(dateString)) {
        return holiday;
      }
    }
    return null;
  }

  function getHighestCalorieMealImage(meals) {
    let highestCalorieMeal = meals.reduce((prev, current) => (prev.calories > current.calories) ? prev : current);
    return highestCalorieMeal.imagePath;
  }

  function updateCalendarWithMeals(calendarData) {
    calendarData.forEach(dayData => {
      let dayElement = document.getElementById(dayData.date);
      let meals = dayData.meals;
      let imagePath = getHighestCalorieMealImage(meals);

      let imgElement = document.createElement('img');
      imgElement.src = `./images/foodicon/${imagePath}`;
      imgElement.alt = meals.find(meal => meal.imagePath === imagePath).mealName;
      imgElement.classList.add('meal-image');

      dayElement.appendChild(imgElement);
    });
  }

  function generateCalendar(year, month) {
    calendarBody.innerHTML = "";
    
    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    let date = 1;

    for (let i = 0; i < 6; i++) {
      let row = document.createElement("tr");

      for (let j = 0; j < 7; j++) {
        let cell = document.createElement("td");

        if (j === 0) cell.classList.add("sunday");
        if (j === 6) cell.classList.add("saturday");

        if (i === 0 && j < firstDay) {
          cell.textContent = "";
        } else if (date > lastDate) {
          break;
        } else {
          let formattedDate = `${("0" + (month + 1)).slice(-2)}-${("0" + date).slice(-2)}`;

          if (holidays[formattedDate]) {
            cell.classList.add("holiday");
            cell.title = holidays[formattedDate];
          }

          let lunarHoliday = isLunarHoliday(year, month, date);
          if (lunarHoliday) {
            cell.classList.add("holiday");
            cell.title = lunarHoliday;
          }

          cell.innerHTML = `<div class="date">${date}</div>`;

          if (date === todayDate && year === today.getFullYear() && month === today.getMonth()) {
            cell.classList.add("today");
          }

          cell.setAttribute("id", `${year}-${("0" + (month + 1)).slice(-2)}-${("0" + date).slice(-2)}`);
          
          const clickedDate = date;
          cell.addEventListener("click", function () {
            selectedDateInfo.textContent = `${year}년 ${month + 1}월 ${clickedDate}일`;
            selectedBreakfast.textContent = "아침: 아침 메뉴";
            selectedLunch.textContent = "점심: 점심 메뉴";
            selectedDinner.textContent = "저녁: 저녁 메뉴";
          });

          date++;
        }
        row.appendChild(cell);
      }
      calendarBody.appendChild(row);
    }
  }

  fetch('/mealsData')
    .then(response => response.json())
    .then(calendarData => updateCalendarWithMeals(calendarData))
    .catch(error => console.error('Error fetching meal data:', error));

  document.getElementById("prevYear").addEventListener("click", function () {
    currentYear--;
    generateCalendar(currentYear, currentMonth);
    updateYearMonthDisplay();
  });

  document.getElementById("nextYear").addEventListener("click", function () {
    currentYear++;
    generateCalendar(currentYear, currentMonth);
    updateYearMonthDisplay();
  });

  document.getElementById("prevMonth").addEventListener("click", function () {
    if (currentMonth === 0) {
      currentMonth = 11;
      currentYear--;
    } else {
      currentMonth--;
    }
    generateCalendar(currentYear, currentMonth);
    updateYearMonthDisplay();
    calculateMonthlyNutrients(currentYear, currentMonth); // 월 이동 시 영양소 합계 업데이트
  });

  document.getElementById("nextMonth").addEventListener("click", function () {
    if (currentMonth === 11) {
      currentMonth = 0;
      currentYear++;
    } else {
      currentMonth++;
    }
    generateCalendar(currentYear, currentMonth);
    updateYearMonthDisplay();
    calculateMonthlyNutrients(currentYear, currentMonth); // 월 이동 시 영양소 합계 업데이트
  });

  generateCalendar(currentYear, currentMonth);
  updateYearMonthDisplay();
  displayTodayInfo();

  // 새로운 요소 가져오기
  const sumKcal = document.getElementById("sumKcal");
  const sumCarbohydrate = document.getElementById("sumCarbohydrate");
  const sumProtein = document.getElementById("sumProtein");
  const sumFat = document.getElementById("sumFat");

  // 사용자 ID 가져오기
  const userId = document.querySelector(".calendar-container").dataset.userId;
  console.log("User ID:", userId);

  let kcal = 0;
  let carbohydrate = 0;
  let protein = 0;
  let fat = 0;

  // 월별 영양소 합계 계산 함수
  function calculateMonthlyNutrients(year, month) {
    kcal = 0;
    carbohydrate = 0;
    protein = 0;
    fat = 0;

    fetch(`/api/calendars/month?userId=${userId}&year=${year}&month=${month + 1}`)
      .then(response => response.json())
      .then(calendarData => {
        const fetchPromises = calendarData.flatMap(calendar => {
          const mealPromises = [];

          if (calendar.breakfast) {
            mealPromises.push(
              fetch(`/api/meal/food?fName=${calendar.breakfast}`)
                .then(response => response.json())
                .then(foodData => {
                  kcal += foodData.kcal || 0;
                  carbohydrate += foodData.carbohydrate || 0;
                  protein += foodData.protein || 0;
                  fat += foodData.fat || 0;
                })
                .catch(error => console.error('Fetch error for breakfast:', error))
            );
          }

          if (calendar.lunch) {
            mealPromises.push(
              fetch(`/api/meal/food?fName=${calendar.lunch}`)
                .then(response => response.json())
                .then(foodData => {
                  kcal += foodData.kcal || 0;
                  carbohydrate += foodData.carbohydrate || 0;
                  protein += foodData.protein || 0;
                  fat += foodData.fat || 0;
                })
                .catch(error => console.error('Fetch error for lunch:', error))
            );
          }

          if (calendar.dinner) {
            mealPromises.push(
              fetch(`/api/meal/food?fName=${calendar.dinner}`)
                .then(response => response.json())
                .then(foodData => {
                  kcal += foodData.kcal || 0;
                  carbohydrate += foodData.carbohydrate || 0;
                  protein += foodData.protein || 0;
                  fat += foodData.fat || 0;
                })
                .catch(error => console.error('Fetch error for dinner:', error))
            );
          }

          return mealPromises;
        });

        Promise.all(fetchPromises)
          .then(() => {
            // 모든 fetch 요청이 완료된 후 총합을 화면에 업데이트
            sumKcal.textContent = `${month + 1}월 총 칼로리 : ${kcal}`;
            sumCarbohydrate.textContent = `탄수화물 : ${carbohydrate}`;
            sumProtein.textContent = `단백질 : ${protein}`;
            sumFat.textContent = `지방 : ${fat} (100g 기준)`;
          })
          .catch(error => console.error('Fetch error:', error));
      })
      .catch(error => console.error('Fetch error:', error));
  }

  // 초기 영양소 합산 계산
  calculateMonthlyNutrients(currentYear, currentMonth);
  // 음식 이미지 매핑 객체 추가
    const foodImageMap = {
      "bagel.png": ['베이글', '크림치즈 베이글', '베이글 샌드위치'],
      "bibimbap.png": ['꼬막비빔밥', '참치 비빔밥', '전주비빔밥'],
      "bossam.png": ['보쌈'],
      "bread.png": ['마늘빵', '갈릭 토스트', '햄 치즈 토스트', '바나나 브레드', '피자 토스트'],
      "chicken.png": ['치킨', '닭갈비', '후라이드 치킨', '바베큐 치킨', '불닭', '레몬 치킨'],
      "corn.png": ['치즈 옥수수'],
      "curry.png": ['카레', '타이 그린 카레', '새우 카레라이스'],
      "fish.png": ['시메사바', '생선구이', '고등어구이', '갈치구이', '삼치구이', '연어구이'],
      "friedpotatoes.png": ['튀김감자', '감자튀김', '칠리 치즈 감자튀김', '트러플 감자튀김'],
      "gamjajorim.png": ['니쿠자가', '감자조림', '감자볶음', '베이컨 감자 샐러드', '구운 감자 샐러드'],
      "hamburger.png": ['햄버거', '치즈버거', '미니 햄버거'],
      "kimbap.png": ['김밥', '베이컨 김밥', '멸치 김밥', '야채 김밥', '깻잎 김밥', '소고기 김밥', '연어 김밥', '참치 김밥', '고추참치 김밥', '돈가스 김밥', '유부 김밥'],
      "kimchi.png": ['김치', '백김치', '물김치', '김치볶음밥', '김치찌개', '김치국', '숙성지 김치찌개'],
      "meat.png": ['스테이크', '삼겹살', '갈비찜', '소불고기', '불고기'],
      "sushi.png": ['초밥', '유부 초밥', '새우 초밥', '날치알 초밥'],
      "noodles.png": ['국수', '칼국수', '잔치국수', '쫄면', '비빔국수'],
      "nuggets.png": ['치킨 너겟', '크림치즈 너겟'],
      "pizza.png": ['피자', '마르게리타 피자', '페퍼로니 피자', '포테이토베이컨 피자', '디아블로 피자', '샐러드 피자'],
      "soup.png": ['감자 수프', '호박 수프', '아스파라거스 수프', '프렌치 어니언 수프', '클램 차우더', '김치찌개', '된장찌개', '순두부찌개', '콩나물국', '떡국', '감자탕', '북엇국', '삼계탕', '설렁탕', '시래기국', '오징어국', '해물탕', '육개장', '배추국', '김치국', '곰탕', '떡만두국', '황태해장국', '해물 수제비', '황태국', '부대찌개', '우거지국', '비지찌개', '콩비지찌개', '감자찌개', '갈비탕', '매운탕', '동태찌개', '미역국', '순대국', '홍합탕', '두부전골', '계란국', '무국', '낙지국', '애호박찌개', '참치국', '사골국', '버섯국', '고추장찌개', '수제비', '청국장', '매운갈비찜', '해물순두부찌개', '만두국', '순두부국', '시래기된장국', '우렁강된장', '낙지탕탕이', '어묵탕', '미소 된장국', '차돌박이 된장찌개', '매운 갈비찜 찌개', '황태찌개', '오삼불고기 찌개', '파김치장어전골', '곱창전골', '우렁 된장찌개', '숙성지 김치찌개', '해물된장찌개'],
      "pasta.png": ['크림치즈 파스타', '알리오 올리오', '토마토 파스타', '트러플 파스타'],
      "onigiri.png": ['주먹밥', '날치알 주먹밥', '오니기리'],
      "ribs.png": ['갈비찜', '돼지갈비', '소갈비', '바베큐 폭립'],
      "rice.png": ['밥', '보리밥', '짜장밥'],
      "ricebowl.png": ['필라프', '덮밥', '삼선짬뽕밥', '소고기 덮밥', '불고기 덮밥', '제육덮밥', '잡채밥'],
      "risotto.png": ['리조또', '버섯 리소토', '새우 크림 리조또', '트러플 리조또'],
      "salad.png": ['샐러드', '시저 샐러드', '과일 샐러드', '포테이토 샐러드', '연어 샐러드'],
      "sashimi.png": ['사시미', '광어 사시미', '연어 사시미', '참치 사시미'],
      "soondae.png": ['순대', '순대국밥'],
      "takoyaki.png": ['타코야키'],
      "tteokbokki.png": ['떡볶이', '로제 떡볶이', '크림 떡볶이']
    };

    // 특정 식사 이름에 맞는 이미지 경로를 찾는 함수 추가
    function findImageForMeal(mealName) {
      for (const [image, meals] of Object.entries(foodImageMap)) {
        if (meals.includes(mealName)) {
          return image;
        }
      }
      return null;
    }

    // 기존의 updateCalendarWithMeals 함수에 이미지 찾기 기능 추가
    function updateCalendarWithMeals(calendarData) {
      calendarData.forEach(dayData => {
        const dayElement = document.getElementById(dayData.date);
        const meals = dayData.meals;
        
        // 각 식사에 대해 이미지 매핑을 찾아 첫 번째 이미지를 사용
        const imagePath = meals.map(meal => findImageForMeal(meal.mealName)).find(path => path);

        if (imagePath) {
          const imgElement = document.createElement('img');
          imgElement.src = `./images/foodicon/${imagePath}`;
          imgElement.alt = meals.find(meal => findImageForMeal(meal.mealName) === imagePath).mealName;
          imgElement.classList.add('meal-image');
          dayElement.appendChild(imgElement);
        }
      });
    }

    // 데이터 로드 후 updateCalendarWithMeals 호출
    fetch('/mealsData')
      .then(response => response.json())
      .then(calendarData => updateCalendarWithMeals(calendarData))
      .catch(error => console.error('Error fetching meal data:', error));

    // 기존 초기화 코드 실행
    generateCalendar(currentYear, currentMonth);
    updateYearMonthDisplay();
    displayTodayInfo();
});
