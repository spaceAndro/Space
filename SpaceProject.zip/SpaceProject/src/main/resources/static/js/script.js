const calendarBody = document.querySelector("#calendar tbody");
const monthYearDisplay = document.querySelector("#monthYear");
const prevMonthBtn = document.querySelector("#prevMonth");
const nextMonthBtn = document.querySelector("#nextMonth");
const prevYearBtn = document.querySelector("#prevYear");
const nextYearBtn = document.querySelector("#nextYear");

let currentDate = new Date();
let currentMonth = currentDate.getMonth();
let currentYear = currentDate.getFullYear();

function generateCalendar(year, month) {
  calendarBody.innerHTML = "";
  
  const firstDay = new Date(year, month, 1).getDay();
  const lastDate = new Date(year, month + 1, 0).getDate();
  
  let date = 1;
  monthYearDisplay.textContent = `${year}년 ${month + 1}월`;
  
  for (let i = 0; i < 6; i++) {
    let row = document.createElement("tr");

    for (let j = 0; j < 7; j++) {
      let cell = document.createElement("td");

      if (i === 0 && j < firstDay) {
        cell.textContent = "";
      } else if (date > lastDate) {
        break;
      } else {
        cell.textContent = date;
        if (
          date === currentDate.getDate() &&
          year === currentDate.getFullYear() &&
          month === currentDate.getMonth()
        ) {
          cell.classList.add("highlight");
        }
        date++;
      }
      row.appendChild(cell);
    }
    calendarBody.appendChild(row);
  }
}

prevMonthBtn.addEventListener("click", () => {
  if (currentMonth === 0) {
    currentMonth = 11;
    currentYear--;
  } else {
    currentMonth--;
  }
  generateCalendar(currentYear, currentMonth);
});

nextMonthBtn.addEventListener("click", () => {
  if (currentMonth === 11) {
    currentMonth = 0;
    currentYear++;
  } else {
    currentMonth++;
  }
  generateCalendar(currentYear, currentMonth);
});

prevYearBtn.addEventListener("click", () => {
  currentYear--;
  generateCalendar(currentYear, currentMonth);
});

nextYearBtn.addEventListener("click", () => {
  currentYear++;
  generateCalendar(currentYear, currentMonth);
});

function initializeCalendar() {
  generateCalendar(currentYear, currentMonth);
}

initializeCalendar();
