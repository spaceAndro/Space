package com.rubypaper.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rubypaper.Repository.UserRepository;
import com.rubypaper.dto.User;

@Controller
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // `login.html`이 `src/main/resources/templates`에 있어야 합니다.
    }

    @GetMapping("/signup")
    public String signupPage() {
        return "signup"; // `signup.html`이 `src/main/resources/templates`에 있어야 합니다.
    }

    @PostMapping("/signup")
    public String registerUser(@ModelAttribute User user) {
        user.setPw(passwordEncoder.encode(user.getPw()));
        userRepository.save(user);
        return "redirect:/login";
    }
    
    @GetMapping("/index")  // GET 요청을 처리
    public String indexPage() {
        return "index"; // `index.html`이 `src/main/resources/templates`에 있어야 합니다.
    }
}
