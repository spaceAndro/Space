package com.rubypaper.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rubypaper.Repository.UserRepository;
import com.rubypaper.dto.User;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // 회원 정보 저장 메서드
    public void saveUser(User user) {
        userRepository.save(user);  // JPA를 이용해 MySQL에 저장
    }
}